import React from "react";

function Services() {
  return (
    <section style={{ padding: "50px" }}>
      <h2>Services</h2>
      <ul>
        <li>SEO (Search Engine Optimization)</li>
        <li>Digital Marketing</li>
        <li>YouTube Promotion</li>
        <li>Social Media Management</li>
        <li>Facebook & Google Ads Campaigns</li>
      </ul>
    </section>
  );
}

export default Services;