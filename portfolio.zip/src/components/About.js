import React from "react";

function About() {
  return (
    <section style={{ padding: "50px" }}>
      <h2>About Me</h2>
      <p>
        I am Ahmed Shakil Noyel, a passionate freelancer specializing in SEO & Digital Marketing.
      </p>
    </section>
  );
}

export default About;