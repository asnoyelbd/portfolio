import React from "react";

function Hero() {
  return (
    <section style={{ textAlign: "center", padding: "50px" }}>
      <h1>Ahmed Shakil Noyel</h1>
      <h2>Freelancer Specialist on SEO & Digital Marketing</h2>
      <p>Professional Freelancer & Digital Marketing Specialist</p>
    </section>
  );
}

export default Hero;