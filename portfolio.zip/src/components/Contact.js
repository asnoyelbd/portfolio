import React from "react";

function Contact() {
  return (
    <section style={{ padding: "50px" }}>
      <h2>Contact Me</h2>
      <p>Email: your-email@example.com</p>
      <p>WhatsApp: <a href="https://wa.me/yourwhatsappnumber" target="_blank" rel="noopener noreferrer">Chat with me</a></p>
      <p>
        <a href="https://linkedin.com/in/yourprofile" target="_blank" rel="noopener noreferrer">LinkedIn</a> | 
        <a href="https://github.com/yourusername" target="_blank" rel="noopener noreferrer"> GitHub</a>
      </p>
    </section>
  );
}

export default Contact;