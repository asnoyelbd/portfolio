import React from "react";

export default function Portfolio() {
  return (
    <div className=\"min-h-screen bg-gray-50 text-gray-800\">
      <section className=\"bg-white shadow-md p-10 text-center\">
        <h1 className=\"text-4xl font-bold\">Ahmed Shakil Noyel</h1>
        <p className=\"text-lg mt-2\">Freelancer Specialist in SEO & Digital Marketing</p>
      </section>
      <section className=\"p-10 max-w-4xl mx-auto\">
        <h2 className=\"text-2xl font-semibold mb-4\">About Me</h2>
        <p>
          I am a passionate freelancer specializing in SEO and Digital Marketing.
          I help businesses grow their online presence, boost visibility, and
          achieve their marketing goals with proven strategies.
        </p>
      </section>
      <section className=\"p-10 bg-gray-100\">
        <h2 className=\"text-2xl font-semibold mb-6 text-center\">Services</h2>
        <div className=\"grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto\">
          <div className=\"p-6 bg-white shadow rounded-lg\">
            <h3 className=\"font-bold mb-2\">SEO Optimization</h3>
            <p>On-page, off-page, and technical SEO for higher rankings.</p>
          </div>
          <div className=\"p-6 bg-white shadow rounded-lg\">
            <h3 className=\"font-bold mb-2\">Digital Marketing</h3>
            <p>Strategies for social media, email, and ad campaigns.</p>
          </div>
          <div className=\"p-6 bg-white shadow rounded-lg\">
            <h3 className=\"font-bold mb-2\">Content Marketing</h3>
            <p>Engaging and optimized content to attract customers.</p>
          </div>
        </div>
      </section>
      <section className=\"p-10 max-w-4xl mx-auto\">
        <h2 className=\"text-2xl font-semibold mb-4\">Contact</h2>
        <p>
          Let’s connect! Reach me via email at
          <a href=\"mailto:ahmedshakil@example.com\" className=\"text-blue-600 ml-1\">
            ahmedshakil@example.com
          </a>
        </p>
        <div className=\"flex space-x-4 mt-4\">
          <a href=\"https://linkedin.com/in/ahmedshakil\" target=\"_blank\" rel=\"noopener noreferrer\" className=\"text-blue-700 font-medium\">
            LinkedIn
          </a>
          <a href=\"https://github.com/ahmedshakil\" target=\"_blank\" rel=\"noopener noreferrer\" className=\"text-gray-800 font-medium\">
            GitHub
          </a>
          <a href=\"https://twitter.com/ahmedshakil\" target=\"_blank\" rel=\"noopener noreferrer\" className=\"text-blue-500 font-medium\">
            Twitter
          </a>
        </div>
      </section>
      <footer className=\"p-6 bg-gray-800 text-white text-center\">
        <p>© {new Date().getFullYear()} Ahmed Shakil Noyel. All rights reserved.</p>
      </footer>
    </div>
  );
}